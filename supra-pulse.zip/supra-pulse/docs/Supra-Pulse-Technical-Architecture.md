# Supra Pulse — Technical Architecture & Implementation Plan

**Version:** 1.0
**Companion doc to:** PRD v1.2, IA & Wireframes v1.0
**Scope:** Stack recommendation, schema, repo structure, build sequence, deployment

**Note on working style:** You've mentioned CLI tools aren't your comfort zone. The stack below is chosen so that day-to-day operation — publishing content, managing the Directory, checking submissions — happens entirely through the Admin Dashboard UI and GUI-based dashboards (Vercel, Supabase). Any CLI/terminal work (initial setup, deployments, schema migrations) is something I handle for you when we get to the build phase — you shouldn't need a terminal to run Supra Pulse day-to-day.

---

## 1. Recommended Stack

| Layer | Choice | Why |
|---|---|---|
| **Frontend/Framework** | Next.js 14+ (App Router) | SSR/ISR for SEO-critical pages (Directory, Project profiles, News), one codebase for frontend + API routes, best-in-class Vercel integration |
| **Styling** | Tailwind CSS | Fast to build a consistent design system; matches the dense, premium aesthetic (Linear/Stripe both effectively use utility-first CSS under the hood) |
| **Database** | PostgreSQL via Supabase | Relational fit for the entity model (Section 11 of PRD), generous free tier, built-in GUI table editor (useful given CLI preference), built-in auth ready for Phase 2 accounts, easy Phase 2/3 upgrade path (RLS, real-time, storage for images) |
| **ORM** | Prisma | Type-safe schema, auto-generated migrations, works cleanly with Next.js API routes, schema file becomes living documentation |
| **Hosting** | Vercel | Native Next.js support, automatic preview deployments per change, zero-downtime deploys, generous free tier for MVP traffic |
| **Image/Asset Storage** | Supabase Storage | Keeps project logos, news images, guide images in the same platform as the DB — one dashboard, not three |
| **Search (MVP)** | Postgres full-text search (via Prisma) | No extra service needed at MVP scale; upgrade to Meilisearch/Algolia only if/when Directory search gets sluggish |
| **Email (newsletter)** | Resend or Beehiiv | Resend if you want full control + simple transactional emails; Beehiiv if you want a built-in newsletter growth/analytics product without building one — recommend Beehiiv given content-marketing goals |
| **Admin Auth** | Simple email/password (or magic link) via Supabase Auth, single account | No need for a custom auth system — Supabase Auth handles this with zero extra infrastructure, and single-editor model means no roles/permissions logic needed |
| **Analytics (site usage)** | Vercel Analytics + Plausible | Privacy-friendly, no cookie-consent overhead, clean dashboards — fits premium/trustworthy brand positioning better than Google Analytics |
| **Error/Uptime Monitoring** | Vercel built-in logs (MVP) → Sentry (Phase 2+) | Don't over-engineer monitoring before there's real traffic |

**Why this combination specifically:** Every piece has a proper GUI dashboard (Vercel, Supabase, Prisma Studio, Resend/Beehiiv) so that after initial setup, you can inspect data, check deploys, and manage content without touching a terminal. I handle the code and CLI-based setup; you operate through dashboards.

---

## 2. Database Schema (Prisma-style, translating PRD Section 11 + vetting checklist)

```prisma
model Project {
  id            String   @id @default(cuid())
  name          String
  slug          String   @unique
  oneLiner      String
  description   String
  logoUrl       String?
  websiteUrl    String
  xUrl          String?
  discordUrl    String?
  telegramUrl   String?
  docsUrl       String?
  category      Category[]
  chainType     ChainType   // EVM, MOVE, ORACLE, MULTI
  status        ProjectStatus // LIVE, TESTNET, COMING_SOON
  hasToken      Boolean  @default(false)
  tokenTicker   String?
  contractAddrs String[] // stored as array of strings

  // Verification (Section 16 checklist as structured fields)
  vc_websiteLive        Boolean @default(false)
  vc_socialsActive       Boolean @default(false)
  vc_teamIdentified      Boolean @default(false)
  vc_noScamHistory        Boolean @default(false)
  vc_confirmedOnSupra    Boolean @default(false)
  vc_clearDescription     Boolean @default(false)
  vc_productStatusAccurate Boolean @default(false)
  vc_metricsVerifiable   Boolean @default(false)
  vc_docsAvailable        Boolean @default(false)
  vc_tokenomicsDisclosed Boolean @default(false)
  vc_contractsPublished  Boolean @default(false)
  vc_redFlagged          Boolean @default(false)
  verificationTier       VerificationTier @default(UNVERIFIED) // VERIFIED, UNVERIFIED, REJECTED
  verificationNote        String?

  featured      Boolean  @default(false)
  createdAt     DateTime @default(now())
  updatedAt     DateTime @updatedAt

  opportunities Opportunity[]
  farmPools     FarmPool[]     // Phase 3
  testnets      Testnet[]
  jobs          Job[]          // Phase 2
  grants        Grant[]
  ambassadorPrograms AmbassadorProgram[]
  newsArticles  ArticleProjectTag[]
  tutorials     TutorialProjectTag[]
}

model Opportunity {
  id          String   @id @default(cuid())
  project     Project  @relation(fields: [projectId], references: [id])
  projectId   String
  title       String
  type        OpportunityType // AIRDROP, QUEST, TESTNET_TASK, OTHER
  description String
  rewardEst   String?
  difficulty  Difficulty // BEGINNER, INTERMEDIATE, ADVANCED
  officialUrl String
  deadline    DateTime?
  status      OpportunityStatus @default(ACTIVE) // ACTIVE, ENDING_SOON, ENDED
  verified    Boolean  @default(true) // false = community-submitted, pending trust signal
  createdAt   DateTime @default(now())
}

model Testnet {
  id            String   @id @default(cuid())
  project       Project  @relation(fields: [projectId], references: [id])
  projectId     String
  title         String
  requirements  String
  reward        String?
  status        TestnetStatus // LIVE, UPCOMING, ENDED
  startDate     DateTime?
  endDate       DateTime?
  officialUrl   String
}

model Grant {
  id           String   @id @default(cuid())
  project      Project? @relation(fields: [projectId], references: [id])
  projectId    String?
  fundingBody  String
  amountRange  String?
  focusArea    String
  deadline     DateTime?
  status       GrantStatus // OPEN, CLOSED, ROLLING
  applyUrl     String
}

model AmbassadorProgram {
  id           String   @id @default(cuid())
  project      Project  @relation(fields: [projectId], references: [id])
  projectId    String
  requirements String
  reward       String?
  applyUrl     String
  status       ProgramStatus // OPEN, CLOSED
}

model Article {
  id          String   @id @default(cuid())
  title       String
  slug        String   @unique
  body        String   // markdown/rich text
  imageUrl    String?
  category    NewsCategory // PROTOCOL_UPDATE, PARTNERSHIP, MARKET, ECOSYSTEM
  sourceUrl   String?      // for aggregated content
  sourceName  String?
  author      String
  publishedAt DateTime?
  status      ContentStatus @default(DRAFT) // DRAFT, PUBLISHED
  createdAt   DateTime @default(now())
  taggedProjects ArticleProjectTag[]
}

model ArticleProjectTag {
  article   Article @relation(fields: [articleId], references: [id])
  articleId String
  project   Project @relation(fields: [projectId], references: [id])
  projectId String
  @@id([articleId, projectId])
}

model Tutorial {
  id          String   @id @default(cuid())
  title       String
  slug        String   @unique
  track       LearningTrack // BEGINNER, DEFI, BUILDER
  body        String
  difficulty  Difficulty
  orderIndex  Int
  readTimeMin Int
  status      ContentStatus @default(DRAFT)
  taggedProjects TutorialProjectTag[]
}

model TutorialProjectTag {
  tutorial   Tutorial @relation(fields: [tutorialId], references: [id])
  tutorialId String
  project    Project  @relation(fields: [projectId], references: [id])
  projectId  String
  @@id([tutorialId, projectId])
}

// Phase 2
model Job {
  id          String   @id @default(cuid())
  project     Project  @relation(fields: [projectId], references: [id])
  projectId   String
  title       String
  type        JobType // FULL_TIME, CONTRACT, BOUNTY
  location    String? // "Remote" or city
  compRange   String?
  applyUrl    String
  postedAt    DateTime @default(now())
  expiresAt   DateTime?
}

// Editorial workflow
model Submission {
  id           String   @id @default(cuid())
  type         SubmissionType // PROJECT, OPPORTUNITY, JOB, TIP
  submittedBy  String?  // email, optional
  payload      Json     // raw submitted data before it becomes a real entity
  status       SubmissionStatus @default(PENDING) // PENDING, APPROVED, REJECTED
  internalNote String?
  createdAt    DateTime @default(now())
  reviewedAt   DateTime?
}

model NewsletterSubscriber {
  id        String   @id @default(cuid())
  email     String   @unique
  createdAt DateTime @default(now())
}

// Enums omitted here for brevity — fully spelled out in the actual schema.prisma
// (Category, ChainType, ProjectStatus, VerificationTier, OpportunityType, Difficulty,
// OpportunityStatus, TestnetStatus, GrantStatus, ProgramStatus, NewsCategory,
// ContentStatus, LearningTrack, JobType, SubmissionType, SubmissionStatus)
```

**Design notes:**
- `verificationTier` is a stored field but is *suggested* by the `vc_*` boolean fields in the Admin UI — you always confirm it manually, per the trust model (no fully automated verification).
- `Submission.payload` is stored as raw JSON so the review queue can hold any submission type without needing draft rows in the real tables — approving a submission is the action that creates the real `Project`/`Opportunity`/`Job` record.
- Junction tables (`ArticleProjectTag`, `TutorialProjectTag`) keep the "related content" cross-linking from the wireframes (Section 4, 5, 6 of IA doc) queryable in both directions.
- `User` and `Watchlist` models are intentionally left out of MVP schema — they arrive in Phase 2 alongside Supabase Auth-based accounts, so we're not maintaining unused tables from day one.

---

## 3. Repo Structure

Single Next.js app (not a monorepo — unnecessary complexity for this scope):

```
supra-pulse/
├── app/
│   ├── (public)/
│   │   ├── page.tsx                 → Homepage
│   │   ├── ecosystem/
│   │   │   ├── page.tsx             → Directory
│   │   │   └── [slug]/page.tsx      → Project Details
│   │   ├── opportunities/
│   │   │   └── page.tsx             → Opportunities Hub
│   │   ├── news/
│   │   │   ├── page.tsx             → News Index
│   │   │   └── [slug]/page.tsx      → Article
│   │   ├── learn/
│   │   │   ├── page.tsx             → Learning Center Index
│   │   │   └── [track]/[slug]/page.tsx → Guide page
│   │   ├── how-we-verify/page.tsx
│   │   ├── submit/page.tsx
│   │   └── about/page.tsx
│   ├── admin/
│   │   ├── page.tsx                 → Admin Overview
│   │   ├── projects/                → Projects Manager
│   │   ├── opportunities/
│   │   ├── news/
│   │   ├── learn/
│   │   ├── submissions/             → Submissions Queue
│   │   └── verification/            → Verification Panel
│   └── api/
│       ├── projects/
│       ├── opportunities/
│       ├── news/
│       ├── learn/
│       ├── submissions/
│       └── newsletter/
├── components/
│   ├── ui/                          → buttons, badges, cards (design system primitives)
│   ├── cards/                       → ProjectCard, OpportunityCard, ArticleCard, GuideCard
│   ├── layout/                      → Nav, Footer, MobileBottomBar
│   └── admin/                       → AdminTable, AdminForm, ChecklistInput
├── lib/
│   ├── prisma.ts                    → Prisma client singleton
│   ├── auth.ts                      → Supabase auth helpers
│   └── validators/                  → form/input validation (zod)
├── prisma/
│   └── schema.prisma
├── public/
└── styles/
```

This structure maps directly onto the IA wireframes — every page in the doc has a corresponding folder, so nothing in the plan is ambiguous when we start building.

---

## 4. Build Sequence (recommended order)

Building in an order that gets you a usable, testable product as early as possible:

**Step 1 — Foundation**
- Next.js project setup, Tailwind config, design system primitives (buttons, badges, cards) matching the visual identity
- Prisma schema + Supabase project provisioned
- Deploy a blank "coming soon" page to Vercel immediately (so the domain is live from day one)

**Step 2 — Admin Dashboard core (build this before public pages)**
- Auth (single account login)
- Projects Manager (full CRUD + verification checklist UI)
- This lets you start entering real projects (working through your vetting checklist) *while* the public pages are still being built — content and code progress in parallel

**Step 3 — Ecosystem Directory + Project Details (public)**
- These read directly from what you've already entered in Step 2, so you get instant visual feedback on real data

**Step 4 — Opportunities Hub, Admin Opportunities/Testnets/Grants/Ambassador managers**

**Step 5 — News (Admin editor + public index/article pages)**

**Step 6 — Learning Center (Admin + public)**

**Step 7 — Homepage** (built last on purpose — it pulls from every other section, so it should be assembled once the underlying data/pages exist, not before)

**Step 8 — Submission flow + Submissions Queue**

**Step 9 — Polish pass:** empty states, loading skeletons, mobile responsive QA, SEO metadata/sitemap, analytics wiring

**Step 10 — Launch**

---

## 5. Content Seeding Plan

Before public launch:
1. Finalize the vetting checklist (already drafted — PRD Section 16)
2. Source and vet the initial 30-50 projects using the checklist, entering them via Admin as Step 2 completes
3. Write 5-10 Learning Center guides (Beginner + Builder tracks)
4. Draft 3-5 initial News articles (mix of original + properly-attributed aggregated pieces)
5. Populate 10-15 initial Active Opportunities so the Opportunities Hub doesn't launch empty

This can happen in parallel with Steps 3-6 of the build sequence, since Admin CRUD is ready by Step 2.

---

## 6. Deployment & Environments

- **Production:** `supra-pulse.xyz` (or your domain) on Vercel, connected to production Supabase project
- **Preview:** Vercel auto-generates a preview URL for every change before it goes live — you can review anything before it's public, no CLI needed
- **Environment variables** (DB connection string, Supabase keys, email API key) managed in Vercel's dashboard UI, not local `.env` files you'd need to edit manually

---

## Decisions Locked (v1.1)

1. **Domain:** `supra-pulse.com` (already owned) — used throughout as the production target. Vercel production deployment will be configured against this domain once we reach deployment.
2. **Newsletter:** Beehiiv for MVP — easy publishing, subscriber growth, referral program built in. Migration path to Resend/custom stays open later if more customization is needed; Beehiiv's export tools make that a non-issue.
3. **Build priority:** Clean, modular, well-documented code from day one. This is a multi-year platform, not a throwaway MVP — architecture decisions below are made with that horizon in mind (e.g., junction tables instead of shortcuts, schema built to extend rather than be rewritten per phase).

## Next Step

Beginning Step 1 (Foundation): Next.js project scaffold, Tailwind config, design system primitives, Prisma schema file, and repo structure as laid out above. Since I don't have access to create Vercel/Supabase accounts on your behalf, I'll build the full codebase here and hand you a ready-to-deploy project plus a short checklist of the account-creation steps only you can do (Vercel sign-up, Supabase project creation, domain DNS pointing) — everything else I'll handle.

---

*End of Technical Architecture & Implementation Plan v1.1.*
