# Supra Pulse — Product Requirements Document (PRD)

**Version:** 1.0 (Draft for Review)
**Owner:** Ibrahim (WEB3SNIPER)
**Status:** Pre-build planning — no code written

---

## 1. Product Vision

Supra Pulse is the single destination where anyone touching the Supra blockchain — beginner or builder — starts their day. It replaces the scattered reality of Discord announcements, Twitter threads, Notion docs, and dead Medium posts with one living, structured, always-current hub.

**Vision statement:** *"If it's happening on Supra, it's on Supra Pulse."*

Where CoinMarketCap indexes tokens and DeFiLlama indexes TVL, Supra Pulse indexes an entire ecosystem's *activity* — projects, opportunities, people, and progress — in one place.

Supra Pulse is an **independent, community-driven platform** — not an official Supra Foundation product. It works closely with the Foundation, ecosystem projects, and community contributors, but maintains editorial independence. This is stated clearly and permanently in the footer and About page. Independence is a trust asset, not a liability: it means Supra Pulse's rankings, verified badges, and coverage can't be bought or dictated by any single party.

**Long-term positioning: Supra Pulse is the operating system of the Supra ecosystem — not a content website.** Every page and feature should be designed to earn a daily visit, not a one-time read. This principle governs prioritization at every phase: live data over static pages, streaks/habits over passive browsing, and utility (farming, jobs, opportunities) over pure media consumption. The architecture below is deliberately built to scale from a curated MVP into that daily-habit OS without a rewrite.

## 2. Mission

To eliminate ecosystem fragmentation for Supra users by aggregating, verifying, and presenting every dApp, opportunity, program, and event in a fast, premium, trustworthy interface — so users never miss an airdrop, a grant deadline, a testnet, or a launch again.

## 3. User Personas

| Persona | Goal | Core Need |
|---|---|---|
| **Beginner** | Understand what Supra is and how to get started | Guided onboarding, simple language, safety |
| **DeFi User** | Find yield, farms, pools | Live APY/TVL data, risk signals |
| **Trader** | Track price action, listings, liquidity | Fast data, alerts, charts |
| **Builder/Developer** | Build on Supra | Docs, testnets, grants, dev tools directory |
| **Investor** | Evaluate ecosystem health & projects | Analytics, funding data, credibility signals |
| **Community Member** | Stay engaged, earn recognition | Ambassador programs, events, content |
| **Job Seeker** | Find Web3 roles in the Supra ecosystem | Jobs board, project directory |

Each persona should have a distinct "entry path" surfaced on the homepage (e.g., a persona-based quick nav: "I'm new" / "I farm" / "I build" / "I invest").

## 4. Website Architecture (Sitemap)

```
Supra Pulse
├── Home
├── Ecosystem Directory
│   ├── All Projects
│   ├── Category pages (DeFi, Infra, Gaming, NFT, Tools, Oracles, etc.)
│   └── Project Profile Page
├── Opportunities (Hub)
│   ├── Active Opportunities (Airdrops/Quests)
│   ├── Farming Dashboard
│   ├── Testnets
│   ├── Grants
│   └── Ambassador Programs
├── Jobs
│   ├── Job Board
│   └── Company Profile
├── News
│   ├── All News
│   └── Article Page
├── Tutorials / Learn
│   ├── Beginner Guides
│   ├── Builder Docs Hub
│   └── Tutorial Page
├── Analytics (Future)
├── AI Assistant (Future)
├── Community
│   ├── Events/Calendar
│   └── Leaderboard (Ambassadors/Contributors)
├── Submit (Project / Job / Opportunity submission)
├── About / Team / Contact
├── How We Verify (trust/methodology page)
└── Account
    ├── Login/Signup
    ├── Watchlist / Saved Items
    ├── Notification Settings
    └── Profile (for ambassadors/contributors)
```

## 5. Navigation Structure

**Primary nav (top bar):** Home · Ecosystem · Opportunities · Jobs · News · Learn · Analytics (soon)
**Secondary/utility (top right):** Search (global, cmd+k style) · Notifications bell · Connect Wallet (optional, future) · Login/Account
**Opportunities mega-menu dropdown:** Active Opportunities · Farming · Testnets · Grants · Ambassador Programs
**Footer:** Sitemap links, Submit Project, Brand/Media Kit, Socials, Newsletter signup, Legal/Disclaimer

Mobile: bottom tab bar (Home, Ecosystem, Opportunities, News, Menu) — crypto-native pattern users already expect.

## 6. Pages & Features

### 6.1 Home
- Hero: live ecosystem stats strip (TVL, # projects, # active opportunities, # testnets live) — DeFiLlama-style ticker
- Persona quick-nav ("New here?" / "Find yield" / "Build" / "Explore jobs")
- Trending Projects carousel
- Active Opportunities preview (top 4-6, with deadline countdowns)
- Latest News (3-4 cards)
- Featured Tutorial / Guide of the week
- Ambassador/Community spotlight
- Newsletter signup CTA

### 6.2 Ecosystem Directory
- Filterable/sortable grid: category, chain component (EVM/Move/etc.), status (live/testnet), TVL, funding
- Search with instant filter
- Each card: logo, name, one-liner, category tag, key metric, verified badge
- **Project Profile Page**: description, links (site/X/Discord/docs), team info (if public), tokenomics summary, associated opportunities/farms/jobs tied to that project, related news, social proof (followers, activity)

### 6.3 Active Opportunities
- Card list: title, project, type (quest/airdrop/testnet task/etc.), reward estimate, deadline countdown, difficulty, status (new/ending soon/ended)
- Filters: category, project, reward type, deadline
- "Notify me" per opportunity (future account feature)
- Verified/Unverified/Community-submitted labeling for trust

### 6.4 Farming Dashboard
- Live table: Pool/Protocol, APY, TVL, Asset pair, Risk tag, Chain
- Sort/filter by APY, TVL, risk
- Click-through to protocol
- Data source disclosure (aggregated vs. self-reported) — critical for trust

### 6.5 Testnets
- List of active/upcoming/past testnets
- Requirements, rewards (if any), how-to-join steps, official links
- Status badges: Live / Upcoming / Ended / Mainnet-launched

### 6.6 Jobs
- Job board: role, company/project, type (FT/contract/bounty), remote/location, comp (if disclosed), posted date
- Filter by role type (dev, community, marketing, design)
- Company profile links back to Ecosystem Directory
- "Post a job" submission flow

### 6.7 Ambassador Programs
- List of active programs across ecosystem projects (not just one)
- Requirements, rewards, application links
- Leaderboard for Supra Pulse's own contributor/ambassador program (community layer)

### 6.8 Grants
- Grant programs list: funding body, amount range, focus area, deadline, application link
- Status: Open / Closed / Rolling

### 6.9 News
- Aggregated + original content feed
- Category tags (Protocol Updates, Partnerships, Market, Ecosystem)
- Source attribution for aggregated content
- Article page: clean reading view, related articles, related project links

### 6.10 Tutorials / Learn
- Beginner track (What is Supra, wallets, bridging, first transaction)
- Builder track (docs, SDKs, smart contract guides)
- DeFi track (how to farm safely, how to evaluate risk)
- Progress-friendly structure (numbered guides, difficulty tags)

### 6.11 Analytics (Future)
- Ecosystem-wide TVL/volume charts
- Wallet growth, transaction count, active addresses
- Project comparison tool

### 6.12 AI Assistant (Future)
- Chat interface: "Find me the highest APY stablecoin farm on Supra" / "What testnets end this week?"
- Grounded only in Supra Pulse's own verified database (avoids hallucination risk)

### 6.13 How We Verify (Trust/Methodology Page) — MVP
- Plain-language explanation of what "Verified by Supra Pulse" means and does *not* mean (not financial advice, not an audit, not an endorsement of investment safety)
- Summary of the vetting checklist categories (Section 16) so users understand the standard without it being a marketing page
- Disclosure of independence from Supra Foundation
- Contact/appeal path for projects that want to be reviewed or dispute a status

## 7. User Journey (Example — DeFi User)

1. Lands on Home → sees live TVL ticker + trending farms
2. Clicks "Find yield" persona shortcut
3. Lands on Farming Dashboard → filters by stablecoin, sorts by APY
4. Clicks into a pool → redirected to protocol page (external) with risk tag shown first
5. Returns, saves protocol to Watchlist (requires free account)
6. Gets notified when APY changes or new pool launches (future notification engine)
7. Subscribes to newsletter for weekly ecosystem digest

## 8. MVP Feature Set — LOCKED SCOPE

**Decision:** MVP ships with six pillars only, to launch as fast as possible without diluting trust or quality.

**Must-have for launch:**
1. **Homepage** — live-feeling hub (even with manually-updated stats), persona quick-nav, trending projects, opportunity previews, latest news, featured tutorial
2. **Ecosystem Directory** — 30-50 seeded, editorially verified projects, full profile pages
3. **Opportunities Hub** — Active Opportunities, Testnets, Grants, and Ambassador Programs consolidated under one hub for MVP (all editorially curated; no live farming APY data yet)
4. **News** — aggregated + original content, editorially published
5. **Learning Center** — beginner + builder tracks, 5-10 guides at launch
6. **Admin Dashboard** — full editorial CMS (see Section 12) to power all of the above

Also included as launch-supporting infrastructure: global search, responsive dark-mode design system, newsletter signup, and a **Submit form that routes to the editorial review queue** — never direct publish (see below).

**Explicitly NOT in MVP:** Jobs board, Farming Dashboard live data, Analytics, AI Assistant, wallet connect, on-chain integrations, user accounts/watchlist, Ambassador leaderboard. These move to Phase 2+ (see Section 9, updated).

### Editorial trust model (non-negotiable for MVP)
- **No day-one public/community publishing.** All Directory, Opportunity, News, and Learning content is entered and verified by the Supra Pulse editorial team via the Admin Dashboard.
- A public "Submit" form exists from day one (for projects, opportunities, tips) but every submission lands in a **pending review queue** — nothing goes live without editorial approval. This builds the community pipeline early without sacrificing trust.
- Every published item carries a "Verified by Supra Pulse" marker so the credibility bar is visible, not just implied.

Rationale: trust is the product's core asset in a space full of scams and rug risk. Manual curation is slower but non-negotiable until editorial standards and review workflows are proven at scale.

## 9. Phased Roadmap

**Phase 1 — MVP (fastest possible launch):** Homepage, Ecosystem Directory, Opportunities Hub (Opportunities/Testnets/Grants/Ambassador programs combined), News, Learning Center, Admin Dashboard, Submit-to-review-queue flow. 100% editorially curated, no live data feeds, no user accounts required to browse.

**Phase 2 (post-MVP, once stable):** Jobs board, user accounts + Watchlist, notification system, Ambassador leaderboard split out as its own daily-engagement feature, newsletter automation, reviewed community submissions flowing in at higher volume.

**Phase 3:** Farming Dashboard with live data (Supra RPC/subgraph or third-party aggregator APIs), basic Analytics (TVL/volume charts) — this is where "content site" starts becoming "operating system."

**Phase 4:** AI Assistant grounded strictly in Supra Pulse's own database, advanced Analytics (project comparisons, wallet growth), streaks/daily-check-in mechanics, API access for partners.

**Phase 5:** Wallet connect for personalized dashboards, on-chain reputation/points system, potential rewards layer for top contributors/ambassadors — this is the full "daily OS" endpoint of the roadmap.

Each phase is additive to the same schema and admin system (Section 11-12), so nothing in the MVP needs to be rebuilt later — only extended.

## 10. Monetization Ideas

- **Featured/Sponsored listings** in Ecosystem Directory (clearly labeled)
- **Sponsored opportunities/quest placements**
- **Job board premium listings** for companies
- **Grants/Ambassador program placement fees** from ecosystem partners
- **Newsletter sponsorships**
- **Supra Pulse Pro** (future): advanced analytics, early opportunity alerts, no ads
- **API access** for other platforms wanting Supra ecosystem data (Phase 4+)
- **Affiliate/referral** on farming/protocol links (disclosed)

Keep monetization visually separate from organic content — critical for trust in a "CoinMarketCap/DeFiLlama" positioning.

## 11. Database Entities (Core Schema Concepts)

- **Project** (id, name, slug, category, description, logo, links, status, chain_type, verified, tags, created_at)
- **Opportunity** (id, project_id FK, title, type, reward_est, deadline, status, difficulty, verified)
- **FarmPool** (id, project_id FK, pair, apy, tvl, risk_tag, source, updated_at)
- **Testnet** (id, project_id FK, title, status, requirements, reward, start_date, end_date)
- **Job** (id, company_id FK, title, type, location, comp_range, posted_at, expires_at)
- **Grant** (id, funding_body, amount_range, focus_area, deadline, link, status)
- **AmbassadorProgram** (id, project_id FK, requirements, reward, link, status)
- **Article/News** (id, title, body, source, author, category, published_at)
- **Tutorial** (id, title, track, difficulty, body, order_index)
- **User** (id, email, role[admin/contributor/user], watchlist, notification_prefs)
- **Submission** (id, type[project/job/opportunity], submitted_by, status[pending/approved/rejected], payload)
- **Category/Tag** (id, name, type)

Design principle: everything links back to **Project**, since the project entity is the ecosystem's core node.

## 12. Admin Dashboard Features

**MVP scope note:** Single-editor model (Ibrahim only). No role-based permission tiers needed for v1 — simplifies build significantly. RBAC is a Phase 2+ addition if the editorial team grows.

- Submission review queue (approve/reject/edit community submissions)
- Project/Opportunity/Job/Grant/Testnet CRUD
- Verified badge assignment, tied to the vetting checklist (Section 16) — checklist fields live in the project's admin record so verification is auditable, not just a toggle
- Featured/sponsored content toggle + scheduling
- News publishing (editor with images, tags, scheduling)
- Tutorial content editor
- Analytics on platform usage (page views, top searched, click-through on opportunities)
- Broken-link/expired-opportunity flagging (auto-flag deadlines that have passed)
- Simple audit log of edits (useful even solo, for tracking what changed and when)

## 13. SEO Strategy

- **Programmatic SEO**: individual pages for every project, opportunity, job, testnet — each indexable, each targeting long-tail queries ("[Project] Supra airdrop", "[Project] APY", "Supra testnet [name]")
- Structured data (schema.org) for Articles, JobPosting, Organization
- Fast Core Web Vitals (static generation/ISR for directory & project pages)
- Canonical URLs, sitemap.xml auto-generated from DB
- Original tutorial/news content targets "how to use Supra," "what is Supra blockchain," "Supra ecosystem" head terms
- Internal linking: every project page links to its opportunities/jobs/news, and vice versa
- Backlink strategy: partner with listed projects to link back to their Supra Pulse profile

## 14. Security Considerations

- No custody of funds; if wallet connect is added later, read-only connections only, never request signing beyond authentication
- Strict input validation/sanitization on all submission forms (XSS, injection)
- Rate limiting on submission and search endpoints
- Admin panel: role-based access control, 2FA required for admin/editor accounts
- Clear "verified vs community-submitted" labeling to reduce scam/rug risk exposure for users
- Disclaimer footer on farming/opportunity data ("not financial advice, DYOR")
- HTTPS everywhere, CSP headers, dependency scanning in CI
- Regular review of external links to prevent linking to compromised/phishing sites (automated link-health checks)

## 15. Technical Architecture (High-Level)

**Frontend:** Next.js (React) — SSR/ISR for SEO-critical pages (directory, project profiles, news), dark-mode design system, Tailwind for styling velocity matching the premium/minimal aesthetic.

**Backend:** Node.js/Next.js API routes or a separate API service (e.g., NestJS) once complexity grows — REST or GraphQL for the admin/content layer.

**Database:** PostgreSQL (relational — fits the entity relationships above well) with an ORM (Prisma).

**Search:** Postgres full-text search initially; upgrade to Algolia/Meilisearch when directory scales.

**Hosting:** Vercel (frontend, matches Next.js) + managed Postgres (e.g., Supabase/Neon/RDS).

**Content/Admin:** Custom admin dashboard (not a generic CMS) so opportunity/testnet/farming data models are purpose-built.

**Future data layer (Phase 3+):** Supra RPC/indexer or subgraph-style service for live farming/analytics data; caching layer (Redis) for frequently-hit endpoints like the live stats ticker.

**AI Assistant (Phase 4):** Retrieval-augmented, grounded strictly in Supra Pulse's own database (projects/opportunities/news) to avoid hallucinated financial claims — no open-ended crypto advice generation.

---

## 16. Directory Vetting Checklist (Draft — for your review)

This is the gatekeeping standard for every project entering the Directory, and the basis of the "Verified by Supra Pulse" badge. Proposed first draft, based on standard Web3 due-diligence practice — react/edit before it's finalized:

**A. Legitimacy & Identity**
- [ ] Official website is live and functional
- [ ] Official social accounts (X/Discord/Telegram) exist, are active, and match the site's linked accounts
- [ ] Team is either publicly identified, or credibly pseudonymous with a track record (prior projects, notable community standing)
- [ ] No prior public scam/rug allegations found in a basic search

**B. Supra Ecosystem Relevance**
- [ ] Confirmed deployed on Supra (mainnet or testnet) — not just "planning to" or "considering"
- [ ] Clear description of what the project does and how it uses Supra's tech (Move/EVM/oracle/etc.)

**C. Product Status**
- [ ] Live product / working testnet / or clearly-labeled "in development" status — status must be accurately reflected in the Directory listing
- [ ] If claiming TVL/users/volume, at least one verifiable source (dashboard, explorer, or reputable third-party tracker)

**D. Documentation & Transparency**
- [ ] Docs or whitepaper available (even minimal)
- [ ] Tokenomics disclosed if a token exists, or explicitly stated as "no token"
- [ ] Contract addresses published where applicable

**E. Red Flags (auto-disqualify or flag for manual review)**
- [ ] Guaranteed-return language or unrealistic yield promises
- [ ] No verifiable team AND no verifiable product (anonymous + vaporware = hold)
- [ ] Copy-paste site/branding from another known project

**Verification tiers (proposed):**
- **Verified** — passes all of A-D, no red flags
- **Listed (Unverified)** — included for visibility/completeness but flagged as not yet fully vetted (useful for new/early-stage projects you don't want to bury, but shouldn't badge yet)
- **Rejected** — fails legitimacy or hits a red flag; not listed

This checklist should live as structured fields in the Admin Dashboard's project record (Section 12), not just a mental process — so verification is consistent and auditable as the Directory scales.



1. **Positioning:** Independent, community-driven platform. Not a Supra Foundation product. Works closely with Foundation/ecosystem but retains editorial independence — stated clearly on-site.
2. **Trust model:** 100% editorial curation for MVP. No direct community publishing on day one. Submissions go to a review queue.
3. **MVP scope:** Homepage, Ecosystem Directory, Opportunities Hub, News, Learning Center, Admin Dashboard. Jobs, Farming Dashboard, Analytics, AI Assistant deferred to later phases.
4. **North star:** Supra Pulse becomes the daily-use "operating system" of the Supra ecosystem — architecture is built for that scale from day one even though MVP ships lean.
5. **Editorial access:** Single-editor model for MVP. Only Ibrahim has publishing/edit rights in the Admin Dashboard. No multi-user roles or permission tiers needed at launch — simplifies Admin Dashboard scope (see Section 12 update) and removes any need for RBAC in v1. Multi-editor support becomes a Phase 2 decision if/when a team is brought on.
6. **Verified by Supra Pulse badge:** Confirmed for MVP. A public "How We Verify" methodology page is part of the launch scope (added to Section 6 and sitemap) so the badge has a transparent, credible standard behind it from day one — not just a visual label.
7. **Directory sourcing:** A written vetting checklist is produced *before* any project is added to the Directory. This checklist is the gatekeeping tool for both the initial 30-50 seed list and all future editorial review-queue decisions. See Section 16 (new).

## Open Questions for Next Round

1. Should the "How We Verify" page be purely informational, or should it also show a visible checklist/score per project (transparency into *why* something is verified)?
2. For the vetting checklist (Section 16) — do you want to draft the criteria together now, or should I propose a first draft based on standard Web3 due-diligence practices for you to react to?

---

*PRD v1.2 — MVP scope, editorial access, trust badge, and vetting process locked. Awaiting your review before any code or wireframes are produced.*
