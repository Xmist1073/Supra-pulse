# Supra Pulse — Information Architecture & Wireframes

**Version:** 1.0
**Companion doc to:** Supra Pulse PRD v1.2
**Scope:** Homepage, Opportunities Hub, Ecosystem Directory, Project Details, News, Learning Center, User Dashboard, Admin Dashboard

**Design DNA:** Linear's precision + Stripe's clarity + Apple's restraint + CoinMarketCap/DeFiLlama's data density — filtered through Supra's dark/red identity. Every page should feel fast before it even loads (skeleton states, not spinners), and dense-but-never-cluttered.

**Global note on scope:** The User Dashboard (accounts/watchlist) is a Phase 2 feature per the PRD. It's designed here in full so the schema and UI shell can be planned now, but it will not ship in MVP — it's included because you asked for the complete UX vision before any code.

---

## 1. Homepage

### Purpose
First impression + daily habit trigger. Must answer three questions in under 5 seconds: "Is this ecosystem alive?", "What's new/urgent?", and "Where do I go for what I need?" It's a dashboard, not a landing page.

### Layout (top to bottom)

**1. Top Navigation Bar** (sticky)
- Left: Supra Pulse logo/wordmark
- Center-left: Primary nav — Ecosystem · Opportunities · News · Learn
- Right: Global search (icon, expands to cmd+k style overlay) · Notification bell (Phase 2, greyed/hidden in MVP) · "Sign In" button (Phase 2 — in MVP this can be a disabled/"Coming Soon" state or simply omitted)
- Mobile: logo + hamburger + search icon only; nav collapses to slide-in drawer

**2. Live Ecosystem Stats Strip**
- Horizontal ticker/bar directly under nav: `# Projects Tracked` · `# Active Opportunities` · `# Testnets Live` · `Last Updated: [timestamp]`
- MVP: values pulled from Admin Dashboard counts (not live on-chain data) — labeled subtly as ecosystem-tracked stats, not financial data
- Component: thin, high-contrast strip, red accent numerals, DeFiLlama-style density

**3. Hero Section**
- Large headline: mission-driven, e.g., "Everything happening on Supra. One place."
- Subheadline: one sentence value prop
- Primary CTA button: "Explore Ecosystem" → Ecosystem Directory
- Secondary CTA (text link): "New to Supra? Start here" → Learning Center beginner track
- Background: subtle animated grid/particle texture in dark red-on-black, restrained (Linear-style ambient motion, not distracting)

**4. Persona Quick-Nav**
- Row of 4 tappable cards: "I'm New" / "I Farm & Earn" / "I Build" / "I Invest"
- Each routes to a pre-filtered view (e.g., "I Farm" → Opportunities Hub filtered to yield-type opportunities)
- Mobile: horizontal scroll row

**5. Trending Projects Carousel**
- Section header: "Trending in the Ecosystem" + "View All →" link to Directory
- 4-6 project cards: logo, name, one-liner, category tag, Verified badge if applicable
- Card click → Project Details Page
- Mobile: horizontal swipe carousel, snap-scroll

**6. Active Opportunities Preview**
- Section header: "Active Opportunities" + "View All →" link to Opportunities Hub
- 4-6 cards: title, project logo, type tag (Airdrop/Quest/Testnet/Grant), deadline countdown chip (color-coded: green >7 days, amber <7 days, red <48hrs)
- Card click → opportunity detail (modal or dedicated view, see Opportunities Hub spec)
- Empty state (if <4 live opportunities exist): show placeholder cards with "New opportunities added weekly — check back soon" + CTA to newsletter signup

**7. Latest News**
- Section header: "Latest News" + "View All →"
- 3 article cards: image, headline, category tag, published date, 1-line excerpt
- Mobile: stacked, full-width cards

**8. Featured Tutorial / Guide of the Week**
- Single wide card: guide title, difficulty tag, estimated read time, "Start Learning →" CTA
- Rotates weekly via Admin Dashboard "featured" flag

**9. Newsletter CTA Band**
- Full-width band, contrasting background: "Get the weekly Supra Pulse digest" + email input + Subscribe button
- Confirmation state: inline success message, no page redirect

**10. Footer**
- Sitemap columns: Ecosystem / Opportunities / News / Learn / About
- "Submit a Project" and "How We Verify" links (trust signals surfaced in footer, not buried)
- Social icons (X, Discord, Telegram)
- Independence disclaimer line: "Supra Pulse is an independent, community-driven platform and is not an official product of the Supra Foundation."
- Legal/Privacy/Terms links

### Buttons & Actions Summary
| Element | Action |
|---|---|
| "Explore Ecosystem" | → Ecosystem Directory |
| "Start here" | → Learning Center (beginner track) |
| Persona cards | → filtered Opportunities/Directory/Learn views |
| Project/Opportunity/News cards | → respective detail pages |
| "View All →" links | → respective hub pages |
| Newsletter Subscribe | → inline success/error state, no redirect |
| Search icon | → opens global search overlay |

### Navigation Flow
Homepage acts as the hub-of-hubs: every section is a preview of a deeper page. No dead ends — every card and section header has a clear "go deeper" path.

### Mobile-First Responsive Behavior
- Single-column stack, in the same section order
- Stats strip becomes horizontally scrollable if it doesn't fit
- Carousels use native swipe/snap
- Hero CTA buttons stack vertically, full-width
- Sticky bottom tab bar (Home / Ecosystem / Opportunities / News / More) replaces some top-nav reliance

### Empty States
- No trending projects yet → show "Ecosystem directory launching soon" placeholder with Submit CTA
- No opportunities live → see Section 6 empty state above
- No news yet → hide section entirely rather than show empty cards (never ship a visibly empty section on a premium product)

### Loading States
- Skeleton screens (grey pulse blocks matching card shapes) for stats strip, carousels, and cards — never a spinner-only blank page
- Stats strip shows last-cached numbers with a subtle "updating…" indicator rather than blanking out

### Future Expansion Areas
- Personalized homepage once accounts ship (Phase 2): "Your Watchlist" section replaces/supplements Trending
- Live on-chain stats ticker (Phase 3, replacing manually-updated counts)
- AI Assistant entry point widget (Phase 4)
- Notification bell becomes functional (Phase 2)

---

## 2. Opportunities Hub

### Purpose
The single feed of everything actionable right now — airdrops, quests, testnets, grants, ambassador programs. This is the "don't miss out" engine and the page most likely to be checked daily.

### Layout (top to bottom)

**1. Page Header**
- Title: "Opportunities" + short subhead: "Every active way to earn, contribute, or get involved on Supra."
- Segmented control / tab row: All · Airdrops & Quests · Testnets · Grants · Ambassador Programs

**2. Filter Bar** (sticky under tabs on scroll)
- Filters: Category (dropdown), Project (searchable dropdown), Deadline (Ending Soon / This Week / This Month / No Deadline), Status (New / Ending Soon / Ended — toggle to show/hide ended)
- Sort: Newest / Deadline Soonest / Most Popular (Phase 2, needs click tracking)
- Mobile: filters collapse into a single "Filters" button opening a bottom sheet

**3. Opportunity Cards Grid** (2-3 col desktop, 1 col mobile)
Each card includes:
- Project logo + name
- Opportunity title
- Type tag (color-coded: Airdrop=red accent, Testnet=blue, Grant=green, Ambassador=purple)
- Deadline countdown chip
- Difficulty indicator (Beginner/Intermediate/Advanced) — small icon
- Verified/Community-submitted badge
- "View Details" — click opens detail view

**4. Opportunity Detail** (modal on desktop, full-screen sheet on mobile — avoids a full page navigation for a lightweight read)
- Full description, requirements/steps, reward estimate, official link (opens in new tab, clearly marked external), related project link, deadline, verification status
- CTA: "Go to Official Site" (primary) + "Save" (Phase 2, requires account — MVP shows this as disabled with tooltip "Sign in to save — coming soon")

**5. "Notify Me" Band** (bottom of page)
- "Never miss a deadline — get opportunity alerts" + email capture (reuses newsletter infra in MVP; becomes true push notifications in Phase 2)

### Buttons & Actions Summary
| Element | Action |
|---|---|
| Tab row | Filters grid to opportunity type |
| Filter Bar controls | Refines grid in place, no page reload |
| Opportunity card | Opens detail modal/sheet |
| "Go to Official Site" | Opens external link, new tab |
| "Save" | Phase 2 — disabled state in MVP |
| Notify Me signup | Inline success state |

### Navigation Flow
Directory-style browse → filter → detail modal → external action (leave site) or return to grid. Project logo/name in card and detail both link to that Project's Details Page — cross-linking the two hubs.

### Mobile-First Responsive Behavior
- Tabs become a horizontally scrollable pill row
- Filter bar collapses to a single button → bottom sheet with all filter controls
- Cards go full-width single column
- Detail view is a full-screen sheet with a clear back/close (X top-left, swipe-down-to-dismiss gesture)

### Empty States
- No opportunities in a filtered view: "No active [type] right now — check back soon or explore other categories" + button resetting filters
- Zero opportunities platform-wide (very early launch risk): show a "Launching Soon" state per category with Submit CTA rather than a bare empty grid

### Loading States
- Skeleton cards (same grid shape, pulsing grey blocks) while data loads
- Filter changes show a brief inline loading shimmer on the grid only (nav/header stay static — no full-page reload feel)

### Future Expansion Areas
- Personal "Saved Opportunities" list (Phase 2, ties to User Dashboard)
- Push/email deadline alerts (Phase 2)
- Community submission volume increasing → need pagination/infinite scroll tuning
- Popularity sorting via click analytics (Phase 2)
- Eventually farming opportunities (yield) could integrate here or stay separate once Farming Dashboard ships (Phase 3) — decide based on usage patterns post-launch

---

## 3. Ecosystem Directory

### Purpose
The canonical index of every project on Supra. This is the CoinMarketCap/DeFiLlama-style backbone page — the one most likely to earn backlinks and long-tail SEO traffic.

### Layout (top to bottom)

**1. Page Header**
- Title: "Ecosystem Directory" + subhead: "Every verified project building on Supra."
- Total count badge: "127 Projects" (dynamic)

**2. Search + Filter Bar**
- Search input (instant filter, no submit needed)
- Category filter chips: DeFi, Infra, Gaming, NFT, Tools, Oracles, etc. (multi-select)
- Status filter: Live / Testnet / Coming Soon
- Verification filter: Verified only toggle
- Sort: Alphabetical / Newest / Trending (Phase 2 needs traffic data)

**3. Project Grid** (3-4 col desktop, 2 col tablet, 1 col mobile)
Each card:
- Logo, name, one-liner description (truncated)
- Category tag(s)
- Status badge (Live/Testnet/Coming Soon)
- Verified checkmark (if applicable) — Listed/Unverified projects show a neutral "Unverified" tag instead, never hidden, per the trust model
- Key metric if available (e.g., "Testnet Live" or a manually-entered TVL figure, clearly dated)

**4. "Don't see a project?" Band**
- "Submit a project for review" CTA → Submission form (routes to editorial queue per PRD trust model)

### Buttons & Actions Summary
| Element | Action |
|---|---|
| Search input | Instant client-side/server filter |
| Category chips | Multi-select filter, updates grid |
| Verified toggle | Filters to verified-only |
| Project card | → Project Details Page |
| Submit CTA | → Submission form |

### Navigation Flow
Directory → filter/search → Project Details Page → (from there) related Opportunities/News/Jobs tied to that project, plus a path back to Directory via breadcrumb.

### Mobile-First Responsive Behavior
- Search bar sticky at top on scroll
- Category chips horizontally scrollable
- Filter panel collapses into "Filters" button + bottom sheet (consistent pattern with Opportunities Hub for muscle memory across the product)
- Grid becomes single column, cards slightly more compact (logo+name+tag, description hidden until tap — keeps mobile scroll fast)

### Empty States
- Search/filter yields zero results: "No projects match your filters" + "Clear Filters" button
- Pre-launch/very early directory (few projects): no artificial padding — ship with what's genuinely vetted, use a "New projects added weekly" note instead of fake density

### Loading States
- Skeleton grid matching card layout
- Search-as-you-type shows a subtle shimmer only on affected cards, not a full reload

### Future Expansion Areas
- Trending/sort-by-traffic once analytics exist (Phase 3)
- TVL-based sort once Farming Dashboard/live data lands (Phase 3)
- Category pages as standalone SEO-optimized URLs (e.g., `/ecosystem/defi`) — plan URL structure now even if launched later
- Comparison tool (select 2-3 projects, side-by-side) — Phase 4 analytics territory

---

## 4. Project Details Page

### Purpose
The canonical profile for a single project — the page every other hub (Opportunities, Jobs, News) links back to. This is also the primary SEO landing page target ("[Project] Supra airdrop", "[Project] Supra review").

### Layout (top to bottom)

**1. Header Block**
- Logo (large), Project name, Verified badge (or Unverified tag), Category tag(s), Status badge
- One-line description
- Action row: official website (icon link), X/Discord/Telegram icons, "Visit Site →" primary button (external link)

**2. About Section**
- Full description (editorially written/curated)
- "What it uses Supra for" — short technical note (Move/EVM/oracle/etc.), directly serving builder/investor personas

**3. Key Info Panel** (right rail desktop / stacked block mobile)
- Status: Live/Testnet/Coming Soon
- Chain component (EVM/Move/etc.)
- Verification tier + link to "How We Verify"
- Token: yes/no, ticker if applicable
- Links: Docs, Whitepaper, Contract address(es) if applicable

**4. Related Opportunities** (if any tied to this project)
- Mini opportunity cards, same style as Opportunities Hub, filtered to this project
- "View all opportunities from [Project] →" if more than shown

**5. Related Jobs** (Phase 2, once Jobs board ships) — placeholder section hidden until then

**6. Related News**
- 2-3 news cards mentioning/tagged with this project

**7. Similar Projects**
- 3-4 cards from the same category, encouraging continued browsing (retention loop)

**8. Breadcrumb / Back Nav**
- Top of page: Ecosystem Directory > [Category] > [Project Name]

### Buttons & Actions Summary
| Element | Action |
|---|---|
| "Visit Site →" | External link, new tab |
| Social icons | External links, new tab |
| Related Opportunity cards | → Opportunities Hub detail |
| Related News cards | → Article page |
| Similar Project cards | → that project's Details Page |
| Breadcrumb | → Directory or category filter |

### Navigation Flow
Entry points: Directory grid, Trending carousel (homepage), Opportunity card project link, News article project tag, direct SEO landing. Exit points: external site (primary conversion), or deeper into the ecosystem via related content (retention).

### Mobile-First Responsive Behavior
- Header block stacks: logo+name+badges row, then description, then action buttons full-width
- Key Info Panel moves from right rail to a collapsible section below About (accordion, collapsed by default to keep initial scroll short)
- Related sections stack vertically, each horizontally swipeable within its section

### Empty States
- No related opportunities/news/jobs: section is hidden entirely (never show an empty "Related Opportunities" block)
- Missing optional fields (e.g., no whitepaper): field simply omitted from Key Info Panel, not shown as "N/A" clutter

### Loading States
- Skeleton for header (logo circle + text bars) and each related-content row independently, so fast-loading sections (like header) don't wait on slower ones (like related news query)

### Future Expansion Areas
- Live metrics panel (TVL, volume, active users) once Analytics/Farming data integrates (Phase 3)
- Team/funding info section if disclosed (useful for investor persona)
- User reviews/ratings — high scam-risk if not moderated carefully, so deliberately deferred and flagged for future trust/safety design work, not just a roadmap add
- "Claim this project" flow allowing verified teams to self-manage their listing (Phase 3+, needs its own auth/verification flow)

---

## 5. News

### Purpose
Timely credibility layer — proves the platform is alive and editorially active, supports SEO for ecosystem-wide terms, and is a natural daily-check trigger alongside Opportunities.

### Layout — News Index

**1. Page Header**
- Title: "News" + category filter tabs: All / Protocol Updates / Partnerships / Market / Ecosystem

**2. Featured Article** (top story, larger card)
- Image, headline, excerpt, author, date, category tag

**3. Article Grid** (3 col desktop, 1 col mobile)
- Standard cards: image, headline, excerpt, category tag, date
- Infinite scroll or "Load More" (avoid full pagination for a news feed — matches modern reading patterns)

### Layout — Article Page
- Breadcrumb: News > [Category] > [Title]
- Headline, author, date, category tag, estimated read time
- Body content (clean reading typography, generous line height — Apple/Stripe editorial style)
- Inline project tags/links where the article references ecosystem projects (auto-links to Project Details Page)
- Source attribution block if aggregated content ("Originally reported by [Source]" with external link)
- End-of-article: "Related Articles" (3 cards) + "Related Projects" (if tagged)
- Share icons (X, Telegram, copy link)

### Buttons & Actions Summary
| Element | Action |
|---|---|
| Category tabs | Filters index grid |
| Article card | → Article page |
| Project tag inline/end | → Project Details Page |
| Source attribution link | External link, new tab |
| Share icons | Native share / copy link |
| Load More | Appends next page of articles |

### Navigation Flow
Homepage preview → News Index → Article → (Related Article loop or Related Project cross-link) — designed to maximize session depth, not just single-article reads.

### Mobile-First Responsive Behavior
- Featured article becomes a compact hero card, not oversized
- Grid single-column
- Article body: comfortable reading width, larger tap targets on share/related links
- Category tabs horizontally scrollable

### Empty States
- No articles in a category filter: "No [category] news yet — check back soon" + link back to All
- Pre-launch (few articles total): featured + grid gracefully handle 1-3 articles without looking broken (avoid grid gaps — collapse to fewer columns if fewer items)

### Loading States
- Skeleton featured card + skeleton grid cards
- "Load More" shows inline spinner only on the button, not the whole page

### Future Expansion Areas
- Newsletter digest auto-generated from top weekly articles (Phase 2 automation)
- Editorial video/podcast content type (long-term)
- Sentiment/trend tagging tied to Analytics (Phase 3+)

---

## 6. Learning Center

### Purpose
Serves the Beginner persona directly and the Builder persona's docs-adjacent needs — also a strong long-tail SEO surface ("what is Supra blockchain," "how to bridge to Supra").

### Layout — Learning Center Index

**1. Page Header**
- Title: "Learning Center" + subhead: "Everything you need to understand and build on Supra."

**2. Track Selector** (3 large cards, not small tabs — this is a browsing decision, give it weight)
- Beginner Track / DeFi Track / Builder Track
- Each card: icon, short description, "X guides" count

**3. Guide List** (within selected track)
- List/grid of guides: title, difficulty tag, estimated read time, numbered order (guides are sequential within a track, encouraging progression)
- Completed/progress indicators — Phase 2 (requires accounts); MVP shows no progress state, just clean numbered list

### Layout — Tutorial/Guide Page
- Breadcrumb: Learning Center > [Track] > [Guide Title]
- Title, difficulty tag, read time
- Body content (step-by-step formatting, code blocks where relevant for Builder track, generous whitespace)
- "Next Guide →" / "← Previous Guide" footer nav (encourages track completion)
- Related Project links if the guide references specific dApps (e.g., a "how to bridge" guide links the bridge project)

### Buttons & Actions Summary
| Element | Action |
|---|---|
| Track cards | → filtered guide list |
| Guide list item | → Guide page |
| Next/Previous Guide | Sequential nav within track |
| Related Project link | → Project Details Page |

### Navigation Flow
Homepage featured guide or persona quick-nav ("I'm New") → Learning Center → Track → sequential guide progression → completion loop back to track index or into Directory/Opportunities once basics are learned.

### Mobile-First Responsive Behavior
- Track selector cards stack vertically, full-width
- Guide list: simple stacked rows (numbered), tap target full-row-height for easy mobile tapping
- Guide page: same reading-optimized layout as News articles for UI consistency across content types

### Empty States
- Track with no guides yet: "Guides coming soon" placeholder, doesn't block other tracks from being browsed
- MVP ships with 5-10 guides total — index should look intentionally curated at that size, not sparse (use track cards prominently so 5 guides across 2 tracks still feels substantial)

### Loading States
- Skeleton for track cards and guide list rows
- Guide page body: skeleton text-line blocks while content loads

### Future Expansion Areas
- Progress tracking + completion badges (Phase 2, ties to User Dashboard)
- Quizzes/interactive checks (long-term)
- Video guide format
- Builder track expands into full docs hub with search (as Supra's own dev tooling matures)

---

## 7. User Dashboard *(Phase 2 — designed now, not built in MVP)*

### Purpose
Personal home base once accounts ship: watchlist, saved opportunities, notification preferences, and (for contributors) ambassador/reputation status. This is the feature that converts Supra Pulse from "a site I visit" to "a tool I use."

### Layout (top to bottom)

**1. Dashboard Header**
- User name/avatar, "Member since [date]"
- Quick stats: # projects watched, # opportunities saved

**2. Watchlist Section**
- Grid of saved Projects (same card style as Directory) with a "Remove" action on hover/long-press
- Empty state: "You haven't saved any projects yet" + CTA to Directory

**3. Saved Opportunities Section**
- List of saved opportunities with deadline countdowns, sorted soonest-first
- Empty state: CTA to Opportunities Hub

**4. Notification Preferences**
- Toggle list: New opportunities in watched categories / Deadline reminders / Weekly digest / Project updates for watched projects

**5. Contributor/Ambassador Status** (conditional — only shown if user has contributor role)
- Points/leaderboard rank, badges earned, submission history

### Buttons & Actions Summary
| Element | Action |
|---|---|
| Remove (watchlist item) | Removes from list, undo toast |
| Notification toggles | Instant save, inline confirmation |
| "Browse Directory/Opportunities" empty-state CTAs | → respective hub |

### Navigation Flow
Accessed via account menu (top nav, once auth ships) — private, not indexed/crawlable.

### Mobile-First Responsive Behavior
- Sections stack vertically, single column
- Watchlist/Saved Opportunities become swipe-to-remove list items rather than grid cards (more mobile-native than hover actions)

### Empty States
- Fully new account: dashboard shows a short onboarding checklist instead of empty sections ("Save your first project," "Set notification preferences") — turns emptiness into activation guidance

### Loading States
- Skeleton matching each section's shape, loaded independently (watchlist shouldn't block notification prefs from rendering)

### Future Expansion Areas
- Personalized homepage feed pulling from watchlist (feeds back into Section 1 future expansion)
- On-chain wallet-linked identity/reputation (Phase 5)
- Points/rewards system tied to platform engagement, not just ambassador submissions

---

## 8. Admin Dashboard

### Purpose
The editorial engine powering the entire platform. Single-editor model (Ibrahim only, per PRD v1.2) — no multi-user permissions in MVP, which keeps this dramatically simpler than a typical CMS.

### Layout — Admin Home
- Sidebar nav: Overview / Projects / Opportunities / News / Learning Center / Submissions Queue / Verification / Settings
- Overview panel: quick stats (total projects, pending submissions count, opportunities expiring this week, last published article date) — the "what needs my attention today" view

### Layout — Projects Manager
- Table view: Name, Category, Status, Verification Tier, Last Updated — sortable/searchable
- "+ Add Project" button → form with all Project Details Page fields, including the Section 16 vetting checklist as structured checkboxes (not free text) so verification tier can be semi-auto-suggested from checklist completion
- Row click → edit form (same as add, pre-filled)
- Bulk actions: none needed at single-editor MVP scale — keep it simple

### Layout — Opportunities / News / Learning Center Managers
- Same table + form pattern as Projects, tailored fields per entity (per PRD Section 11 schema)
- News manager includes a rich text/markdown editor with image upload
- Opportunities manager includes deadline field with auto-flagging (auto-marks "Ended" status when deadline passes, surfaces in Overview panel for cleanup)

### Layout — Submissions Queue
- List of pending community submissions (project/opportunity/tip type)
- Each item: submitted content preview, submitter info (if provided), Approve / Reject / Edit-then-Approve actions
- Approve → runs through the same vetting checklist as manual entries before going live (queue doesn't bypass verification standards)
- Rejected items: archived with optional internal note (for consistency if the same project resubmits later)

### Layout — Verification Panel
- Cross-reference view: all projects with checklist completion %, sortable, flags anything "Listed (Unverified)" for follow-up review — this is the operational view that keeps the trust model from decaying as the Directory grows

### Buttons & Actions Summary
| Element | Action |
|---|---|
| + Add [Entity] | Opens creation form |
| Table row | Opens edit form |
| Approve/Reject (Submissions) | Moves item to live content or archive |
| Verification checklist boxes | Auto-updates suggested tier, editor confirms |
| Save/Publish | Commits change, updates live site immediately (no separate staging step needed at this scale) |

### Navigation Flow
Sidebar-driven, single-level depth per section (list → form → back to list) — deliberately simple since it's a single-user tool, not a complex multi-role CMS.

### Mobile-First Responsive Behavior
- Admin is primarily a desktop tool (editorial work isn't mobile-first by nature), but should remain functional on mobile/tablet for on-the-go approvals: sidebar collapses to a top dropdown, tables become stacked card lists, forms remain full-screen single-column (already mobile-friendly by default)

### Empty States
- Empty Submissions Queue: "No pending submissions — you're all caught up" (positive, not sparse-feeling)
- New platform with few entries: Overview panel shows guidance/next-step prompts rather than zeroed-out stat blocks

### Loading States
- Standard skeleton tables/forms
- Save/Publish actions show inline button-loading state (spinner replaces button label briefly), with toast confirmation on success/failure

### Future Expansion Areas
- Multi-editor support with RBAC (Phase 2, if team grows)
- Scheduled publishing (queue content to go live at a specific time)
- Version history/rollback per entity
- Analytics tab surfacing platform usage data directly in Admin (Phase 3, ties to Analytics feature)
- Automated red-flag detection assist (e.g., flag suspicious submission patterns) — long-term, not urgent at launch scale

---

## Cross-Page Design System Notes

- **Card component** is the atomic unit across Directory, Opportunities, News, and Learning — keep visual language consistent (same corner radius, shadow/border treatment, badge placement) so the product feels like one system, not eight different pages
- **Verification badge** styling must be identical everywhere it appears (Directory, Opportunities, Project Details) — consistency here is a trust signal, not just a design one
- **External link indicator** (small icon) should be used consistently anywhere a click leaves Supra Pulse, per premium-product convention (Stripe/Linear both do this well)
- **Bottom sheet pattern** (mobile filters, opportunity details) should be the standard mobile interaction for anything that's a modal on desktop — one consistent gesture language across the app
- **Skeleton-first loading** everywhere, no bare spinners on primary content areas — this is a big part of the "premium/fast" feel the brief calls for

---

*End of Information Architecture & Wireframes v1.0. Next step (pending your review): Technical Architecture & Implementation Plan.*
