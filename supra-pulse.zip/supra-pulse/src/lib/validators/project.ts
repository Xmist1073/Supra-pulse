import { z } from "zod";

/**
 * Mirrors the Project model in prisma/schema.prisma. Used by both the
 * Admin project form and the /api/projects route handlers so client and
 * server validation can never drift apart.
 */
export const categoryEnum = z.enum([
  "DEFI",
  "INFRA",
  "GAMING",
  "NFT",
  "TOOLS",
  "ORACLE",
  "DAO",
  "OTHER",
]);

export const projectSchema = z.object({
  name: z.string().min(2, "Name is required"),
  slug: z
    .string()
    .min(2)
    .regex(/^[a-z0-9-]+$/, "Slug must be lowercase, numbers, and hyphens only"),
  oneLiner: z.string().min(10, "One-liner should be at least 10 characters").max(140),
  description: z.string().min(30, "Description should be at least 30 characters"),
  logoUrl: z.string().url().optional().or(z.literal("")),
  coverImageUrl: z.string().url().optional().or(z.literal("")),
  whyItMatters: z.string().max(500).optional().or(z.literal("")),
  websiteUrl: z.string().url("Must be a valid URL"),
  xUrl: z.string().url().optional().or(z.literal("")),
  discordUrl: z.string().url().optional().or(z.literal("")),
  telegramUrl: z.string().url().optional().or(z.literal("")),
  docsUrl: z.string().url().optional().or(z.literal("")),
  githubUrl: z.string().url().optional().or(z.literal("")),
  category: z.array(categoryEnum).min(1, "Select at least one category"),
  chainType: z.enum(["EVM", "MOVE", "ORACLE", "MULTI"]),
  status: z.enum(["LIVE", "TESTNET", "COMING_SOON"]),
  hasToken: z.boolean(),
  tokenTicker: z.string().optional(),
  contractAddrs: z.array(z.string()).default([]),

  // Section 16 vetting checklist — see docs/Supra-Pulse-PRD.md
  vcWebsiteLive: z.boolean(),
  vcSocialsActive: z.boolean(),
  vcTeamIdentified: z.boolean(),
  vcNoScamHistory: z.boolean(),
  vcConfirmedOnSupra: z.boolean(),
  vcClearDescription: z.boolean(),
  vcProductStatusAccurate: z.boolean(),
  vcMetricsVerifiable: z.boolean(),
  vcDocsAvailable: z.boolean(),
  vcTokenomicsDisclosed: z.boolean(),
  vcContractsPublished: z.boolean(),
  vcRedFlagged: z.boolean(),
  verificationTier: z.enum(["VERIFIED", "UNVERIFIED", "REJECTED"]),
  verificationNote: z.string().optional(),

  featured: z.boolean(),
});

export type ProjectInput = z.infer<typeof projectSchema>;

/** Checklist field keys in display order — drives the ChecklistInput UI so
 * the form and the schema can never fall out of sync. */
export const vettingChecklist: {
  key: keyof ProjectInput;
  label: string;
  group: "Legitimacy & Identity" | "Ecosystem Relevance" | "Product Status" | "Documentation" | "Red Flags";
}[] = [
  { key: "vcWebsiteLive", label: "Official website is live and functional", group: "Legitimacy & Identity" },
  { key: "vcSocialsActive", label: "Official socials exist, are active, and match linked accounts", group: "Legitimacy & Identity" },
  { key: "vcTeamIdentified", label: "Team is public or credibly pseudonymous with a track record", group: "Legitimacy & Identity" },
  { key: "vcNoScamHistory", label: "No prior public scam/rug allegations found", group: "Legitimacy & Identity" },
  { key: "vcConfirmedOnSupra", label: "Confirmed deployed on Supra (mainnet or testnet)", group: "Ecosystem Relevance" },
  { key: "vcClearDescription", label: "Clear description of what it does and how it uses Supra", group: "Ecosystem Relevance" },
  { key: "vcProductStatusAccurate", label: "Product status (live/testnet/dev) is accurately reflected", group: "Product Status" },
  { key: "vcMetricsVerifiable", label: "Any claimed TVL/users/volume has a verifiable source", group: "Product Status" },
  { key: "vcDocsAvailable", label: "Docs or whitepaper available", group: "Documentation" },
  { key: "vcTokenomicsDisclosed", label: "Tokenomics disclosed, or explicitly stated as no token", group: "Documentation" },
  { key: "vcContractsPublished", label: "Contract addresses published where applicable", group: "Documentation" },
  { key: "vcRedFlagged", label: "Red flag present (guaranteed returns, vaporware, copy-paste branding)", group: "Red Flags" },
];
