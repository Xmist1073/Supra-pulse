import { PrismaClient } from "@prisma/client";

/**
 * Prisma client singleton — prevents exhausting the Supabase connection
 * pool from hot-reloading new clients in dev. Standard Next.js pattern.
 */
const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === "development" ? ["error", "warn"] : ["error"],
  });

if (process.env.NODE_ENV !== "production") {
  globalForPrisma.prisma = prisma;
}
