import { createBrowserClient } from "@supabase/ssr";

/**
 * Browser-side Supabase client, used only in the admin login form to
 * submit credentials. All authenticated data fetching happens server-side.
 */
export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
