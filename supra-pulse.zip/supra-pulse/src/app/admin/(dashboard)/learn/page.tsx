export default function AdminLearnPage() {
  return (
    <div>
      <h1 className="font-display text-2xl font-semibold">Learning Center</h1>
      <p className="mt-1 text-sm text-text-secondary">
        The guide editor lands here in the next build step.
      </p>
    </div>
  );
}
