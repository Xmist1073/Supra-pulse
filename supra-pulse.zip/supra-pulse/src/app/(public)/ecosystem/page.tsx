import type { Metadata } from "next";
import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { ProjectCard } from "@/components/cards/ProjectCard";
import { DirectoryFilters } from "@/components/directory/DirectoryFilters";
import type { Category, ProjectStatus, Prisma } from "@prisma/client";

export const metadata: Metadata = {
  title: "Ecosystem Directory",
  description:
    "Every verified project building on Supra — DeFi, infrastructure, gaming, NFTs, tools, and oracles, in one searchable directory.",
};

// Revalidate periodically rather than on every request — the Directory
// changes when the editor publishes, not on every visitor, so this keeps
// the page fast at scale without needing a cache-invalidation webhook yet.
export const revalidate = 300;

const PAGE_SIZE = 24;

interface PageProps {
  searchParams: Promise<{
    q?: string;
    category?: string | string[];
    status?: string;
    verified?: string;
    page?: string;
  }>;
}

export default async function EcosystemDirectoryPage({ searchParams }: PageProps) {
  const params = await searchParams;
  const page = Math.max(1, Number(params.page) || 1);
  const categories = params.category
    ? Array.isArray(params.category)
      ? params.category
      : [params.category]
    : [];

  const where: Prisma.ProjectWhereInput = {
    ...(params.q
      ? {
          OR: [
            { name: { contains: params.q, mode: "insensitive" } },
            { oneLiner: { contains: params.q, mode: "insensitive" } },
          ],
        }
      : {}),
    ...(categories.length > 0
      ? { category: { hasSome: categories as Category[] } }
      : {}),
    ...(params.status ? { status: params.status as ProjectStatus } : {}),
    ...(params.verified === "true" ? { verificationTier: "VERIFIED" } : {}),
  };

  const [projects, total] = await Promise.all([
    prisma.project.findMany({
      where,
      orderBy: [{ featured: "desc" }, { name: "asc" }],
      skip: (page - 1) * PAGE_SIZE,
      take: PAGE_SIZE,
    }),
    prisma.project.count({ where }),
  ]);

  const totalPages = Math.ceil(total / PAGE_SIZE);
  const hasFilters = Boolean(params.q || categories.length || params.status || params.verified);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-semibold tracking-tight">
            Ecosystem Directory
          </h1>
          <p className="mt-1 text-text-secondary">
            Every verified project building on Supra.
          </p>
        </div>
        <p className="font-mono text-sm text-text-tertiary">
          {total} project{total === 1 ? "" : "s"}
        </p>
      </div>

      <div className="mt-6">
        <DirectoryFilters />
      </div>

      {projects.length === 0 ? (
        <EmptyState hasFilters={hasFilters} />
      ) : (
        <>
          <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {projects.map((project) => (
              <ProjectCard key={project.id} project={project} />
            ))}
          </div>

          {totalPages > 1 && (
            <Pagination page={page} totalPages={totalPages} searchParams={params} />
          )}
        </>
      )}

      <div className="mt-16 rounded-[--radius-card] border border-dashed border-hairline p-8 text-center">
        <p className="text-text-primary">Don&rsquo;t see a project?</p>
        <p className="mt-1 text-sm text-text-secondary">
          Every submission goes through editorial review before it&rsquo;s
          listed.
        </p>
        <Link
          href="/submit"
          className="mt-4 inline-flex rounded-[--radius-control] border border-hairline px-4 py-2 text-sm text-text-primary hover:border-signal/40"
        >
          Submit a project
        </Link>
      </div>
    </div>
  );
}

function EmptyState({ hasFilters }: { hasFilters: boolean }) {
  return (
    <div className="mt-12 flex flex-col items-center rounded-[--radius-card] border border-dashed border-hairline py-16 text-center">
      <p className="text-text-secondary">
        {hasFilters
          ? "No projects match your filters."
          : "New projects are added weekly — check back soon."}
      </p>
      {hasFilters && (
        <Link
          href="/ecosystem"
          className="mt-4 text-sm text-signal-hover hover:underline"
        >
          Clear filters
        </Link>
      )}
    </div>
  );
}

function Pagination({
  page,
  totalPages,
  searchParams,
}: {
  page: number;
  totalPages: number;
  searchParams: Record<string, string | string[] | undefined>;
}) {
  function hrefForPage(target: number) {
    const params = new URLSearchParams();
    Object.entries(searchParams).forEach(([key, value]) => {
      if (key === "page" || !value) return;
      if (Array.isArray(value)) value.forEach((v) => params.append(key, v));
      else params.set(key, value);
    });
    params.set("page", String(target));
    return `/ecosystem?${params.toString()}`;
  }

  return (
    <nav className="mt-10 flex items-center justify-center gap-2">
      <Link
        href={hrefForPage(Math.max(1, page - 1))}
        aria-disabled={page === 1}
        className={`rounded-[--radius-control] border border-hairline px-3 py-1.5 text-sm ${
          page === 1
            ? "pointer-events-none text-text-tertiary"
            : "text-text-secondary hover:border-signal/40"
        }`}
      >
        Previous
      </Link>
      <span className="font-mono text-sm text-text-tertiary">
        {page} / {totalPages}
      </span>
      <Link
        href={hrefForPage(Math.min(totalPages, page + 1))}
        aria-disabled={page === totalPages}
        className={`rounded-[--radius-control] border border-hairline px-3 py-1.5 text-sm ${
          page === totalPages
            ? "pointer-events-none text-text-tertiary"
            : "text-text-secondary hover:border-signal/40"
        }`}
      >
        Next
      </Link>
    </nav>
  );
}
