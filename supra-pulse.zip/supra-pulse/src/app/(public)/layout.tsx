import { Nav } from "@/components/layout/Nav";
import { Footer } from "@/components/layout/Footer";

/**
 * Wraps every public content page (Ecosystem, Opportunities, News, Learn)
 * with the shared Nav/Footer. The root "/" page stays outside this group
 * intentionally — it's still the pre-launch coming-soon placeholder.
 */
export default function PublicLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <>
      <Nav />
      <div className="flex-1">{children}</div>
      <Footer />
    </>
  );
}
