# Supra Pulse

The independent ecosystem hub for the Supra blockchain — projects, opportunities, testnets, grants, news, and learning resources, all in one place.

Production domain: **supra-pulse.com**

## Planning docs

Full product/design/technical planning lives in `/docs`:
- `Supra-Pulse-PRD.md` — product vision, personas, MVP scope, entities
- `Supra-Pulse-IA-Wireframes.md` — page-by-page UX spec for every screen
- `Supra-Pulse-Technical-Architecture.md` — stack, schema rationale, build sequence

Read these before making structural changes — they're the source of truth for *why* things are built the way they are, not just *what*.

## Stack

- **Framework:** Next.js 15+ (App Router, TypeScript)
- **Styling:** Tailwind CSS v4 (token system in `src/app/globals.css`)
- **Database:** PostgreSQL via Supabase, accessed through Prisma (`prisma/schema.prisma`)
- **Auth:** Supabase Auth (single editor account for MVP)
- **Newsletter:** Beehiiv
- **Hosting:** Vercel

## Local development

```bash
npm install
cp .env.example .env   # fill in Supabase + Beehiiv credentials
npx prisma generate
npx prisma migrate dev
npm run dev
```

## Project structure

```
src/
  app/                → routes (App Router) — one folder per page in the IA doc
  components/
    ui/                → design system primitives (Button, Badge, Card, PulseDot)
    cards/             → ProjectCard, OpportunityCard, ArticleCard, GuideCard
    layout/            → Nav, Footer, MobileBottomBar
    admin/             → AdminTable, AdminForm, ChecklistInput
  lib/                 → Prisma client, auth helpers, validators
prisma/
  schema.prisma        → full data model (Projects, Opportunities, News, etc.)
docs/                  → planning documents (see above)
```

## Design system

Tokens are defined in `src/app/globals.css` and mapped into Tailwind via `@theme inline`. Three type faces, used deliberately:

- **Space Grotesk** — display/headlines only
- **Inter** — body copy and UI
- **IBM Plex Mono** — numerals, stats, countdowns (the "terminal pulse" signature)

The signal red (`--color-signal`) is reserved for live/urgent/primary-action meaning — never decorative. See the `PulseDot` component for the platform's signature motif.

## Status

Step 3 complete — Ecosystem Directory + Project Details are live (public-facing):
- **Directory** (`/ecosystem`): server-side search/filter via URL params (search, category, status, verified-only), paginated at 24/page, ISR-cached (5 min) — built to stay fast at hundreds of projects without client-side array filtering
- **Project Details** (`/ecosystem/[slug]`): cover banner, logo, category/status/verification badges, description, "why it matters," full link set (website/X/Discord/Telegram/Docs/GitHub), token info, active opportunities, tutorials, latest news, similar projects, last-updated timestamp — all cross-linked from the same Project record entered in Admin
- **SEO**: per-project `generateMetadata` + OpenGraph, JSON-LD Organization structured data, dynamic `sitemap.xml` covering every project automatically, `robots.txt` blocking `/admin` and `/api`
- **Scale**: `generateStaticParams` pre-renders every project at build time; new/edited projects revalidate via ISR rather than needing a full rebuild
- Admin Projects Manager extended with the new fields (cover banner, why it matters, GitHub)

**Known sandbox limitation (unchanged):** `binaries.prisma.sh` isn't reachable from the build sandbox, so `prisma generate` couldn't run here — see Local development below. Every other file type-checks cleanly against the schema.

Next build step: Opportunities Hub (public) + its Admin managers (Opportunities/Testnets/Grants/Ambassador Programs).


