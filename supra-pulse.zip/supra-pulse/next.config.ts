import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  images: {
    // Project logos/banners are entered by the editor and can come from
    // any domain — allow all https sources rather than maintaining a
    // manual allowlist that would break every time a new project is added.
    remotePatterns: [{ protocol: "https", hostname: "**" }],
  },
};

export default nextConfig;
